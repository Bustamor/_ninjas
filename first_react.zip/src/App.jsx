import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello World</h1>
      <h2>Things I need to do:</h2>

        <li>Learn React</li>
        <li>Climb Mt. Everest</li>
        <li>Run a marthon</li>
        <li>Feed the dogs</li>
      
    </div>
  );
}

export default App;
